export interface Library {
  title: string;
  description: string;
  link: string;
}
