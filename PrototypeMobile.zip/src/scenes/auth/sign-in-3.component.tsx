import React from 'react';
import ContentView from '../../layouts/auth/sign-in-3';

export const SignIn3Screen = ({ navigation }): React.ReactElement => (
  <ContentView navigation={navigation}/>
);
