import React from 'react';
import ContentView from '../../layouts/auth/forgot-password';

export const ForgotPasswordScreen = ({ navigation }): React.ReactElement => (
  <ContentView navigation={navigation}/>
);
