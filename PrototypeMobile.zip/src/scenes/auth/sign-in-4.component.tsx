import React from 'react';
import ContentView from '../../layouts/auth/sign-in-4';

export const SignIn4Screen = ({ navigation }): React.ReactElement => (
  <ContentView navigation={navigation}/>
);
