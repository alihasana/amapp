import React from 'react';
import ContentView from '../../layouts/auth/sign-up-2';

export const SignUp2Screen = ({ navigation }): React.ReactElement => (
  <ContentView navigation={navigation}/>
);
