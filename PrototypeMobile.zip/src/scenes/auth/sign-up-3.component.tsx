import React from 'react';
import ContentView from '../../layouts/auth/sign-up-3';

export const SignUp3Screen = ({ navigation }): React.ReactElement => (
  <ContentView navigation={navigation}/>
);
