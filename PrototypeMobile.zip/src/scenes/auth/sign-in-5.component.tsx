import React from 'react';
import ContentView from '../../layouts/auth/sign-in-5';

export const SignIn5Screen = ({ navigation }): React.ReactElement => (
  <ContentView navigation={navigation}/>
);
