self.__precacheManifest = [
  {
    "revision": "3367f87a922e59e7f02b",
    "url": "static/js/app.8c9c3d52.chunk.js"
  },
  {
    "revision": "968dd11ad1a0a4cf3e70",
    "url": "static/js/runtime~app.57f5bbf7.js"
  },
  {
    "revision": "d358607d2ab0d2e9eae4",
    "url": "static/js/2.aeb64cf4.chunk.js"
  },
  {
    "revision": "a78e4b51bf5dd2e05c7453e1b5194d45",
    "url": "static/media/image-app-icon.a78e4b51.png"
  },
  {
    "revision": "b531a17a35bf2b09d825269dbd5a1727",
    "url": "static/media/image-product-1.b531a17a.jpeg"
  },
  {
    "revision": "d8db0388b341f6b93fb7e3343665a636",
    "url": "static/media/image-product.d8db0388.jpg"
  },
  {
    "revision": "41618cee586a3a0ce43b32119b43756f",
    "url": "static/media/image-attachment-1.41618cee.png"
  },
  {
    "revision": "32f42f8ef01ce8819f6b87e1c51d67d1",
    "url": "static/media/image-attachment-2.32f42f8e.jpg"
  },
  {
    "revision": "104b5e79323cc8b709f758bc0ad21e08",
    "url": "static/media/image-profile.104b5e79.jpg"
  },
  {
    "revision": "b660a948dbe264cf49164d1aa5fc949c",
    "url": "static/media/image-profile.b660a948.jpg"
  },
  {
    "revision": "b54e03c45ecff6a47bef4b8a7d73d67c",
    "url": "static/media/image-training-1.b54e03c4.jpg"
  },
  {
    "revision": "801683ef46eb589cf1f5aeba5f5859e2",
    "url": "static/media/image-training-2.801683ef.jpg"
  },
  {
    "revision": "c01d06c608c519d12d15e44fe149c230",
    "url": "static/media/image-training-3.c01d06c6.jpg"
  },
  {
    "revision": "0481cee3088a74c79d180bc39a495e21",
    "url": "static/media/image-training-4.0481cee3.jpg"
  },
  {
    "revision": "d09c02f9c01f3e7e8eb6138f4002cb78",
    "url": "static/media/image-product-1.d09c02f9.png"
  },
  {
    "revision": "ac2e6cbbd4c71ad3583ab0b7afcaae45",
    "url": "static/media/icon-auth.ac2e6cbb.png"
  },
  {
    "revision": "1c6ea22152be9cc248407b7798eae283",
    "url": "static/media/icon-auth-dark.1c6ea221.png"
  },
  {
    "revision": "ace4911e1c9c7237382ce7fa87d9f384",
    "url": "static/media/icon-social.ace4911e.png"
  },
  {
    "revision": "cb16511db473db9f5de22cc87370cd0f",
    "url": "static/media/icon-social-dark.cb16511d.png"
  },
  {
    "revision": "6c81954c020f39a7c3b9d2f8f99eca88",
    "url": "static/media/icon-articles.6c81954c.png"
  },
  {
    "revision": "339e48b8dd19750bb50cd1279a799976",
    "url": "static/media/icon-articles-dark.339e48b8.png"
  },
  {
    "revision": "78e70ba957ea5c9b23e11461bca7179d",
    "url": "static/media/icon-messaging.78e70ba9.png"
  },
  {
    "revision": "2d844951a536869a3e2ac17cce5022b6",
    "url": "static/media/icon-messaging-dark.2d844951.png"
  },
  {
    "revision": "e12c4f63ec03e61fee511e801d8880ef",
    "url": "static/media/icon-dashboards-dark.e12c4f63.png"
  },
  {
    "revision": "d33ff0819884216fda6110e7e5637db2",
    "url": "static/media/icon-ecommerce.d33ff081.png"
  },
  {
    "revision": "ac1cefcba0cb2d1cf3864d962ae96c0b",
    "url": "static/media/icon-ecommerce-dark.ac1cefcb.png"
  },
  {
    "revision": "bfafdcc7e5b4df30e7afa088b4d641a5",
    "url": "static/media/icon-autocomplete.bfafdcc7.png"
  },
  {
    "revision": "6c8fba083300e01b636cb431a3b3591a",
    "url": "static/media/icon-autocomplete-dark.6c8fba08.png"
  },
  {
    "revision": "e4785e428ac37a9b263a100a2d2023ed",
    "url": "static/media/icon-avatar.e4785e42.png"
  },
  {
    "revision": "a3e11921904cb7085cebe857df07640f",
    "url": "static/media/icon-avatar-dark.a3e11921.png"
  },
  {
    "revision": "99cfca3d0002f1b01f4c90aae279a83b",
    "url": "static/media/icon-bottom-navigation-dark.99cfca3d.png"
  },
  {
    "revision": "dd18c6d8ce6c9b7e003be0f492ce2bca",
    "url": "static/media/icon-button.dd18c6d8.png"
  },
  {
    "revision": "f092b1b8c04e4ba4b8cdbb88edaf146c",
    "url": "static/media/icon-button-dark.f092b1b8.png"
  },
  {
    "revision": "3d45a84b22b94677a46cbee26560ea19",
    "url": "static/media/icon-button-group-dark.3d45a84b.png"
  },
  {
    "revision": "ae658920d5418d0ef3a049921b1476f1",
    "url": "static/media/icon-calendar.ae658920.png"
  },
  {
    "revision": "054a33a50f13077bf7b991313b4b7527",
    "url": "static/media/icon-calendar-dark.054a33a5.png"
  },
  {
    "revision": "ec6957964538a2ce696183c26d948e02",
    "url": "static/media/icon-card.ec695796.png"
  },
  {
    "revision": "e0d4f94481bfb15219c794db57dea2dd",
    "url": "static/media/icon-card-dark.e0d4f944.png"
  },
  {
    "revision": "68ed43391951e516a337a988ef7d534f",
    "url": "static/media/icon-checkbox-dark.68ed4339.png"
  },
  {
    "revision": "9f728867285af0739a6905078ef4f6f4",
    "url": "static/media/icon-datepicker.9f728867.png"
  },
  {
    "revision": "30a2587c4a2725fae240a924f7a014a7",
    "url": "static/media/icon-datepicker-dark.30a2587c.png"
  },
  {
    "revision": "6f2e7279592cb4cc4991b142dceb6509",
    "url": "static/media/icon-drawer.6f2e7279.png"
  },
  {
    "revision": "a00dfeab62f8b8a50054b50d4afd2294",
    "url": "static/media/icon-drawer-dark.a00dfeab.png"
  },
  {
    "revision": "bcdf0b1cf96a57ad0348b9f24a3a5945",
    "url": "static/media/icon-icon.bcdf0b1c.png"
  },
  {
    "revision": "80b8b98d9273c1278151d0e923f127cf",
    "url": "static/media/icon-icon-dark.80b8b98d.png"
  },
  {
    "revision": "ff6edbc431577a8e4c7cd7ee3f632977",
    "url": "static/media/icon-input.ff6edbc4.png"
  },
  {
    "revision": "138a9013c14d4db6bf4267130fe18c76",
    "url": "static/media/icon-input-dark.138a9013.png"
  },
  {
    "revision": "0cf0bedb0c3cda47b44215fa4ec177e1",
    "url": "static/media/icon-list.0cf0bedb.png"
  },
  {
    "revision": "06f48bf7d4154b6c0fdfe92fd73ae79b",
    "url": "static/media/icon-list-dark.06f48bf7.png"
  },
  {
    "revision": "1a99679bb66d3b795ed1d06408c84551",
    "url": "static/media/icon-menu.1a99679b.png"
  },
  {
    "revision": "99200cb0dc6373f06ae36227c37b3e9a",
    "url": "static/media/icon-menu-dark.99200cb0.png"
  },
  {
    "revision": "341c43b24d78b0de32f9a0c425cdb422",
    "url": "static/media/icon-modal.341c43b2.png"
  },
  {
    "revision": "b8d5fcebda0698b570274348d0fefa45",
    "url": "static/media/icon-modal-dark.b8d5fceb.png"
  },
  {
    "revision": "50dda1eea6a2c0dd34211f2d2633fa0d",
    "url": "static/media/icon-overflow-menu-dark.50dda1ee.png"
  },
  {
    "revision": "a5259814596ca9dd7d6ca4d748b9ede4",
    "url": "static/media/icon-popover-dark.a5259814.png"
  },
  {
    "revision": "4c22516b4ccfb458f0f1fc407a9d305a",
    "url": "static/media/icon-radio.4c22516b.png"
  },
  {
    "revision": "f0f666077cd17e6f653b6f847b5d90fc",
    "url": "static/media/icon-radio-dark.f0f66607.png"
  },
  {
    "revision": "56a126719b97bea0c3ce4420ff094401",
    "url": "static/media/icon-select.56a12671.png"
  },
  {
    "revision": "4d7dd368e69051edaaa86df6eafc2d46",
    "url": "static/media/icon-select-dark.4d7dd368.png"
  },
  {
    "revision": "f316f4b3782e4a3a4c20ddae44d3692c",
    "url": "static/media/icon-spinner.f316f4b3.png"
  },
  {
    "revision": "9b2552c0979d0dd976abb2a4f12c6446",
    "url": "static/media/icon-spinner-dark.9b2552c0.png"
  },
  {
    "revision": "6b0fd996c25e6bc82b72d5fe00d5e354",
    "url": "static/media/icon-tab-view-dark.6b0fd996.png"
  },
  {
    "revision": "aa7f83f6a0e2f53f9f05fb243d7c7c9b",
    "url": "static/media/icon-text-dark.aa7f83f6.png"
  },
  {
    "revision": "337e1f7b843949b38671ef6f2878bee0",
    "url": "static/media/icon-toggle.337e1f7b.png"
  },
  {
    "revision": "9b2408bd7d2f82ed302cc817be6345a5",
    "url": "static/media/icon-toggle-dark.9b2408bd.png"
  },
  {
    "revision": "47149132128428f3f731ecd60dedb6b0",
    "url": "static/media/icon-tooltip.47149132.png"
  },
  {
    "revision": "66240a2bf32a094b7248e33af02ad0ff",
    "url": "static/media/icon-tooltip-dark.66240a2b.png"
  },
  {
    "revision": "5c51f06ca51f19d34badc32249e05c71",
    "url": "static/media/icon-top-navigation.5c51f06c.png"
  },
  {
    "revision": "b53f20f768c960e5af57647161c9a282",
    "url": "static/media/icon-top-navigation-dark.b53f20f7.png"
  },
  {
    "revision": "0f90486c452ccfc6132c1d6bbc9a838d",
    "url": "static/media/image-layout-sign-in-1.0f90486c.jpg"
  },
  {
    "revision": "6cfbe80e2424d288ed688cb19b305d9a",
    "url": "static/media/image-layout-sign-in-2.6cfbe80e.jpg"
  },
  {
    "revision": "d44758b36506cea63b3637cf622f9f44",
    "url": "static/media/image-layout-sign-in-3.d44758b3.jpg"
  },
  {
    "revision": "1d8b0d6ba372b987315ace77777077a7",
    "url": "static/media/image-layout-sign-in-4.1d8b0d6b.jpg"
  },
  {
    "revision": "f9733c949acb3501305fd2d1817969ba",
    "url": "static/media/image-layout-sign-in-5.f9733c94.jpg"
  },
  {
    "revision": "a6780540477903378bd63dd2a5a4d838",
    "url": "static/media/image-layout-sign-up-1.a6780540.jpg"
  },
  {
    "revision": "f757ac00fc80eded9145e1e7ad6f67b6",
    "url": "static/media/image-layout-sign-up-2.f757ac00.jpg"
  },
  {
    "revision": "c843810fdb7ed532871ec988cfc0a78c",
    "url": "static/media/image-layout-sign-up-3.c843810f.jpg"
  },
  {
    "revision": "37060d1177f80f587b5841c6e20d0d1a",
    "url": "static/media/image-layout-sign-up-4.37060d11.jpg"
  },
  {
    "revision": "9b72690bdd0f722615a4cc649ab71afb",
    "url": "static/media/image-layout-forgot-password.9b72690b.jpg"
  },
  {
    "revision": "48c6ed174ac9a6df770a5737e36c703d",
    "url": "static/media/image-background.48c6ed17.jpg"
  },
  {
    "revision": "96bb4dcb3fc9e6d3e4b453347d79ac4b",
    "url": "static/media/image-background.96bb4dcb.jpg"
  },
  {
    "revision": "ba28f9263a9dd4c017e78f5035755b46",
    "url": "static/media/image-background.ba28f926.jpg"
  },
  {
    "revision": "19776f235a5d8159ffc378cad837aacc",
    "url": "static/media/image-background.19776f23.jpg"
  },
  {
    "revision": "8a1df78a63d08aee1e1ff5cdf36d2806",
    "url": "static/media/image-background.8a1df78a.jpg"
  },
  {
    "revision": "cbe3c60a21d18627a82430c5759d3b6b",
    "url": "static/media/image-person.cbe3c60a.png"
  },
  {
    "revision": "a335a9c1cea132ce85151fb6c37511cc",
    "url": "static/media/image-background.a335a9c1.jpg"
  },
  {
    "revision": "877cf9660393b686e8e9021504b4c511",
    "url": "static/media/image-layout-feed-1.877cf966.jpg"
  },
  {
    "revision": "298316479329dc037f28012d8de6c823",
    "url": "static/media/image-layout-feed-2.29831647.jpg"
  },
  {
    "revision": "6a9c202bdc3ac44d47123b14ff31b0a5",
    "url": "static/media/image-layout-profile-1.6a9c202b.jpg"
  },
  {
    "revision": "a700f5bbcf68b9c9faef1f521160d94e",
    "url": "static/media/image-layout-profile-2.a700f5bb.jpg"
  },
  {
    "revision": "c488b0543b593d9448e9a32d58064bc4",
    "url": "static/media/image-layout-profile-3.c488b054.jpg"
  },
  {
    "revision": "e32bee0681f7356b93b9d4fb12501480",
    "url": "static/media/image-layout-profile-4.e32bee06.jpg"
  },
  {
    "revision": "aeec04c7bf2b0dced085adda1a1de098",
    "url": "static/media/image-layout-profile-5.aeec04c7.jpg"
  },
  {
    "revision": "dd89eac8ff2193863754842dd3d30039",
    "url": "static/media/image-layout-profile-6.dd89eac8.jpg"
  },
  {
    "revision": "a2a2cd9f2b1417a90a31ca0491f766f0",
    "url": "static/media/image-layout-profile-7.a2a2cd9f.jpg"
  },
  {
    "revision": "819129d9b8f3cbfc1b2e02553c45abc3",
    "url": "static/media/image-layout-profile-settings-1.819129d9.jpg"
  },
  {
    "revision": "4e4e0a456e460af2e3960778ecf8b3ad",
    "url": "static/media/image-layout-profile-settings-2.4e4e0a45.jpg"
  },
  {
    "revision": "f161a1898d7378d7a5db4449c015f270",
    "url": "static/media/image-layout-profile-settings-3.f161a189.jpg"
  },
  {
    "revision": "04256781e9c675a1a33d91b48da4f305",
    "url": "static/media/image-training-1.04256781.jpg"
  },
  {
    "revision": "5846b46b4e2cef59e2b73724144c25cc",
    "url": "static/media/image-training-2.5846b46b.jpg"
  },
  {
    "revision": "48b928d8a9db4e081cd4205a37b7fee0",
    "url": "static/media/image-training-3.48b928d8.jpg"
  },
  {
    "revision": "475aa95094449bc4d628acdf3c161d1e",
    "url": "static/media/image-profile-1.475aa950.jpg"
  },
  {
    "revision": "d51340092581069bbb15a8645d11c7ee",
    "url": "static/media/image-profile-2.d5134009.jpg"
  },
  {
    "revision": "76067c801cb507750fcb8321948bf3f4",
    "url": "static/media/image-post-1.76067c80.jpg"
  },
  {
    "revision": "d985e9c1bc1d2d0ec64c2588d5201d04",
    "url": "static/media/image-post-2.d985e9c1.jpg"
  },
  {
    "revision": "d51340092581069bbb15a8645d11c7ee",
    "url": "static/media/image-profile.d5134009.jpg"
  },
  {
    "revision": "475aa95094449bc4d628acdf3c161d1e",
    "url": "static/media/image-profile.475aa950.jpg"
  },
  {
    "revision": "de83ed70fbba2ccf589a746b8b19d1af",
    "url": "static/media/image-profile.de83ed70.jpg"
  },
  {
    "revision": "c64d46de39f785bd8fdbad58882ca541",
    "url": "static/media/image-plant-1.c64d46de.jpg"
  },
  {
    "revision": "ac31e6cb3b3e72044c0c03cdc3da1d45",
    "url": "static/media/image-plant-2.ac31e6cb.jpg"
  },
  {
    "revision": "2624294b503775345905c09278e5a9f5",
    "url": "static/media/image-plant-3.2624294b.jpg"
  },
  {
    "revision": "21124f8fadc98732444d774491a5bcb1",
    "url": "static/media/image-travel-1.21124f8f.jpg"
  },
  {
    "revision": "96e083bce344263c047f328b4e3ac04a",
    "url": "static/media/image-travel-2.96e083bc.jpg"
  },
  {
    "revision": "3de005ac78f1be95eabcafff7d4366fd",
    "url": "static/media/image-travel-3.3de005ac.jpg"
  },
  {
    "revision": "9f2aa22ab12f0af63eee8dc861c99b79",
    "url": "static/media/image-style-1.9f2aa22a.jpg"
  },
  {
    "revision": "661fe61a37cc907bbce02ad5ac00ece2",
    "url": "static/media/image-style-2.661fe61a.jpg"
  },
  {
    "revision": "8b1046b426ec9002695a4ee280eee29d",
    "url": "static/media/image-style-3.8b1046b4.jpg"
  },
  {
    "revision": "0eda3125f3331c6a31aa24e189fadf29",
    "url": "static/media/image-profile-3.0eda3125.jpg"
  },
  {
    "revision": "3435b33f34c1fcbf5b8b77f3bdd2516a",
    "url": "static/media/image-background.3435b33f.jpg"
  },
  {
    "revision": "8be0b66fe85d4d05b5591a34a8a90776",
    "url": "static/media/image-layout-article-1.8be0b66f.jpg"
  },
  {
    "revision": "827174dd63aceb667adf1e62df551b4a",
    "url": "static/media/image-layout-article-2.827174dd.jpg"
  },
  {
    "revision": "e053e7e5d37b22e7f7bba2b330ff823a",
    "url": "static/media/image-layout-article-3.e053e7e5.jpg"
  },
  {
    "revision": "1aee8f3a92ca855e1c0e6a6fd73ece2d",
    "url": "static/media/image-layout-article-list-1.1aee8f3a.jpg"
  },
  {
    "revision": "f4e765a91ae29360573237ee0bf9220c",
    "url": "static/media/image-layout-article-list-2.f4e765a9.jpg"
  },
  {
    "revision": "baa2579d83acc3e7ecce4e88de877124",
    "url": "static/media/image-layout-article-list-3.baa2579d.jpg"
  },
  {
    "revision": "bb64fb7a09a02db6a53000937bf656e7",
    "url": "static/media/image-layout-article-list-4.bb64fb7a.jpg"
  },
  {
    "revision": "2cb8eda081a49ecf0f685e33cd86854b",
    "url": "static/media/image-background.2cb8eda0.jpg"
  },
  {
    "revision": "a8abaf65653b999b494e9a690b1dafb3",
    "url": "static/media/image-article-background-1.a8abaf65.jpg"
  },
  {
    "revision": "009ec86f2588fc9d660af3c82467f7a0",
    "url": "static/media/image-article-background-2.009ec86f.jpg"
  },
  {
    "revision": "58a293960a45cff8b429c03a1efed376",
    "url": "static/media/image-article-background-3.58a29396.jpg"
  },
  {
    "revision": "e758d3add688fc15c3ad2ee089f45bf5",
    "url": "static/media/image-layout-chat-1.e758d3ad.jpg"
  },
  {
    "revision": "bf50abda133c5482306e11e95510b809",
    "url": "static/media/image-layout-chat-2.bf50abda.jpg"
  },
  {
    "revision": "f5d7eaeff7b36bef01bf0932cabd9826",
    "url": "static/media/image-layout-conversation-list.f5d7eaef.jpg"
  },
  {
    "revision": "d51340092581069bbb15a8645d11c7ee",
    "url": "static/media/image-profile-1.d5134009.jpg"
  },
  {
    "revision": "475aa95094449bc4d628acdf3c161d1e",
    "url": "static/media/image-profile-2.475aa950.jpg"
  },
  {
    "revision": "fdf577c2b181d31db271d029ba2a0d97",
    "url": "static/media/image-layout-training-1.fdf577c2.jpg"
  },
  {
    "revision": "3cf543183be7efd4b521f452287ee0a7",
    "url": "static/media/image-layout-training-2.3cf54318.jpg"
  },
  {
    "revision": "f7c1179dd238fb8779afdd58b6411b45",
    "url": "static/media/image-layout-settings.f7c1179d.jpg"
  },
  {
    "revision": "9479726d03c7fda2c8abc3729a6f5175",
    "url": "static/media/image-training-5.9479726d.jpg"
  },
  {
    "revision": "0481cee3088a74c79d180bc39a495e21",
    "url": "static/media/image-training-1.0481cee3.jpg"
  },
  {
    "revision": "236b842f15e2de17cb4d707faad808af",
    "url": "static/media/image-layout-product-details-1.236b842f.jpg"
  },
  {
    "revision": "99e0a18a1d59175afca30f9084e24113",
    "url": "static/media/image-layout-product-details-2.99e0a18a.jpg"
  },
  {
    "revision": "66e23763f61dbc188729be245593d162",
    "url": "static/media/image-layout-product-details-3.66e23763.jpg"
  },
  {
    "revision": "4eb87aa2368f0666854459ac790ec2a1",
    "url": "static/media/image-layout-product-details-4.4eb87aa2.jpg"
  },
  {
    "revision": "dd3b4ebab57def66bf8d8e8ecc98282d",
    "url": "static/media/image-layout-product-list.dd3b4eba.jpg"
  },
  {
    "revision": "421a9af368c478f76de292ab34116ffe",
    "url": "static/media/image-layout-shopping-cart.421a9af3.jpg"
  },
  {
    "revision": "7cda0880e27812f25ef24e4c64b2129b",
    "url": "static/media/image-layout-payment.7cda0880.jpg"
  },
  {
    "revision": "f18c041543eb5b425a876dca9cef8d32",
    "url": "static/media/image-layout-add-new-card.f18c0415.jpg"
  },
  {
    "revision": "0a0d1577d89355baab8085a766bc108c",
    "url": "static/media/image-product.0a0d1577.png"
  },
  {
    "revision": "d2ef3e0dedc1b7ab971bdfc8fd35aa8f",
    "url": "static/media/image-product.d2ef3e0d.png"
  },
  {
    "revision": "d09c02f9c01f3e7e8eb6138f4002cb78",
    "url": "static/media/image-product.d09c02f9.png"
  },
  {
    "revision": "fdabc70aa6ab121bfac7b48af833183e",
    "url": "static/media/visa-logo.fdabc70a.png"
  },
  {
    "revision": "24efdfc7f92c9910658ed889b862bb9f",
    "url": "static/media/image-product-2.24efdfc7.jpg"
  },
  {
    "revision": "52f94d6e34f09df07ff8156e6938318b",
    "url": "static/media/image-product-3.52f94d6e.jpg"
  },
  {
    "revision": "5a798cdadc7cd321e3f72425b70bface",
    "url": "./fonts/opensans-regular.ttf"
  },
  {
    "revision": "11eabca2251325cfc5589c9c6fb57b46",
    "url": "./fonts/roboto-regular.ttf"
  },
  {
    "revision": "4b06b5318598a23018740de25028e693",
    "url": "static/media/image-splash.4b06b531.png"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "serve.json"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "favicon.ico"
  },
  {
    "revision": "48c7ed4e7da9792af288a60d7242d615",
    "url": "expo-service-worker.js"
  },
  {
    "revision": "73b7c2cd76d1c2cc010bf945524d760d",
    "url": "manifest.json"
  },
  {
    "revision": "ff5e4630ec683bcf1bf5cc7296462522",
    "url": "apple/icons/icon_180x180.png"
  },
  {
    "revision": "2fd8c8941c8a87c18ae8e77df10b6957",
    "url": "apple/icons/icon_192x192.png"
  },
  {
    "revision": "b5dc6b8d9d68fa46a8bcf1de67366750",
    "url": "apple/icons/icon_512x512.png"
  },
  {
    "revision": "d3fa8f2312d05dd27cc89efd3e6a851d",
    "url": "apple/splash/icon_1125x2436.png"
  },
  {
    "revision": "066df87b2321ae4a0181ce04651cb8f1",
    "url": "apple/splash/icon_1136x640.png"
  },
  {
    "revision": "0429fa613ffb1c8ae84c0a36b1ee63a9",
    "url": "apple/splash/icon_1242x2208.png"
  },
  {
    "revision": "e5f1fd40fbee9fb50110e687b8252784",
    "url": "apple/splash/icon_1242x2688.png"
  },
  {
    "revision": "4f50e55eb738924ff0374ec2b4e532e5",
    "url": "apple/splash/icon_1334x750.png"
  },
  {
    "revision": "412aaa3a4d4964892e016dc8076a5933",
    "url": "apple/splash/icon_1792x828.png"
  },
  {
    "revision": "14404dd2b3ce63d088d18ee50d3e004d",
    "url": "apple/splash/icon_2208x1242.png"
  },
  {
    "revision": "3a7cf44cea2f73932495b2e4762d3fb1",
    "url": "apple/splash/icon_2436x1125.png"
  },
  {
    "revision": "8c94f37a178459ff96593affa3bfb466",
    "url": "apple/splash/icon_2688x1242.png"
  },
  {
    "revision": "5410146ddc50bc7a9dfd06f94473103d",
    "url": "apple/splash/icon_640x1136.png"
  },
  {
    "revision": "1c5545e41680d8acec1936158ae75ee4",
    "url": "apple/splash/icon_750x1334.png"
  },
  {
    "revision": "ca7e85390bc78f88c9c80fe0100e60a0",
    "url": "apple/splash/icon_828x1792.png"
  },
  {
    "revision": "7984f375f0b04bbc9f92fcf727388f05",
    "url": "index.html"
  },
  {
    "revision": "7e58407cb31f65b195e69c72f53b58f6",
    "url": "static/js/runtime~app.57f5bbf7.js.gz"
  },
  {
    "revision": "16709f23227d220b53e235a942bf292c",
    "url": "expo-service-worker.js.gz"
  },
  {
    "revision": "72042d40648a00c3aa0517a46d0d61ee",
    "url": "static/js/app.8c9c3d52.chunk.js.gz"
  },
  {
    "revision": "561e22f1e2ee6d7acc38eda511ab7711",
    "url": "static/js/2.aeb64cf4.chunk.js.gz"
  }
];