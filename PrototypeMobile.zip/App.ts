import App from './src/app/app.component';

export default App;
